module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'e23a21ee-c8bb-4cce-886a-1060145be5f9'
};